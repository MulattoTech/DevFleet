import test from "node:test";import assert from "node:assert/strict";test("smoke",()=>assert.equal(2+3,5));
